Rails.application.routes.draw do
  get 'books/show'
  get 'book/show'
  get 'todolists/new'
  resources :books
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  get "top"=>"homes#top"
  get "todolists" => "todolists#index"
  post "todolists" => "todolists#create"
  get 'todolists/:id/edit' => 'todolists#show'
  delete 'todolists/:id' => 'todolists#destroy', as: 'destroy_todolist'
  get 'todolists/:id' => 'todolists#show', as: 'todolist'
  root "homes#top"
end
